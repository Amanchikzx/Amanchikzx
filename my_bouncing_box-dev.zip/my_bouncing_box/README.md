# Welcome to My Bouncing Box
***

## Task
I was asked to make box bounce, 0 value is defined and x y coordinate for very top left of screen.
Box moves diagonally and when it reaches border it changes direction.
## Description
Initial code was provided by task, I understood that scrypt has to be used for that. I used let for variablr 
and dir for coordination X Y. Indicated speed by using constant. Then approached to ID. Then used function animation. 

## Installation
TODO - How to install your project? npm install? make? make re?

## Usage
It works at least, but gandalf shows only one error. I will submit this task and wait for 
```
./my_project argument1 argument2
```

### The Core Team


<span><i>Made at <a href='https://qwasar.io'>Qwasar SV -- Software Engineering School</a></i></span>
<span><img alt='Qwasar SV -- Software Engineering School's Logo' src='https://storage.googleapis.com/qwasar-public/qwasar-logo_50x50.png' width='20px'></span>
