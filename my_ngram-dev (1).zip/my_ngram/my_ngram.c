#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

void my_ngram(int num_strings, char* str[]) {
    int count[256] = {0};
    for (int i = 0; i < num_strings; i++) {
        size_t str_len = strlen(str[i]);
        for (size_t j = 0; j < str_len; j++) {
            count[(unsigned char)str[i][j]]++;
        }
    }
    for (int i = 0; i < 256; i++) {
        if (count[i] > 0) {
            if(isprint(i)) printf("%c:%d\n", i, count[i]);
            else printf("0x%x:%d\n",i,count[i]);
        }
    }
}

int main(int argc, char *argv[]) {
    my_ngram(argc - 1, argv + 1);
    return 0;
}