# Welcome to My Cat
***

## Task
The program starts by including the "stdio.h" and "stdlib.h" headers, which provide access to standard input/output functions and general purpose utilities, respectively.

The main function takes in two parameters: argc, which is the number of command line arguments, and argv, which is an array of strings that contains the actual command line arguments.

## Description
For each argument, the program opens the file specified by the argument with the "r" mode, which stands for reading. It uses the fopen() function to open the file and assigns the returned file pointer to the 'file' variable.

## Installation
If the file is opened successfully, the program reads the file character by character using the getc() function and prints each character to the standard output using the putchar() function.
The loop continues until the end of the file is reached and getc() returns EOF (End of File)

## Usage
After reading and printing the contents of the file, the program closes the file using the fclose() function.
Finally, the program returns 0, indicating that it ran successfully.

./my_project argument1 argument2
```

### The Core Team


<span><i>Made at <a href='https://qwasar.io'>Qwasar SV -- Software Engineering School</a></i></span>
<span><img alt='Qwasar SV -- Software Engineering School's Logo' src='https://storage.googleapis.com/qwasar-public/qwasar-logo_50x50.png' width='20px'></span>
