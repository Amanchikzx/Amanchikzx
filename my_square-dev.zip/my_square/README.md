# Welcome to My Square
***

## Task
This is a description of a program called "my_square". The purpose of the program is to display a square in the terminal. The size and height of the square are specified as arguments when the program is executed.

The program takes two arguments, the first being the width of the square and the second being the height of the square. The width and height are both specified as integers and passed to the program as command-line arguments. The program converts the strings passed as arguments into integers using the atoi function.

## Description
The program must be compiled using the command "gcc my_file.c" and can be executed using the command "./a.out". To compare the output of the program with an example implementation, the user can execute the command "curl -s https://storage.googleapis.com/qwasar-public/qwasar_my_square.tgz | tar zxvf - -C ./" which will download and extract a file named "qwasar_my_square".

## Installation
The program takes two arguments, the first being the width of the square and the second being the height of the square. The width and height are both specified as integers and passed to the program as command-line arguments. The program converts the strings passed as arguments into integers using the atoi function.

## Usage
It is important to note that the program must be careful to avoid causing a segmentation fault and should be tested thoroughly to ensure it is functioning as expected.
### The Core Team


<span><i>Made at <a href='https://qwasar.io'>Qwasar SV -- Software Engineering School</a></i></span>
<span><img alt='Qwasar SV -- Software Engineering School's Logo' src='https://storage.googleapis.com/qwasar-public/qwasar-logo_50x50.png' width='20px'></span>
