# Welcome to My Printf
***

## Task
This is a program written in C that implements a simplified version of the printf function. The main function of the program calls the my_printf function with different format strings to print various types of data, such as integers, strings, and hexadecimal numbers.

## Description
The my_printf function takes a format string as its first argument and a variable number of arguments of different types, which are specified in the format string using placeholders such as %d, %s, and %x. The function then parses the format string and the arguments and prints the appropriate output.

## Installation
The program also includes helper functions for parsing and printing different types of data, such as strings, characters, and numbers in various bases (decimal, hexadecimal, octal). The program uses the va_list and va_arg macros from the stdarg.h header file to access the variable arguments passed to the my_printf function.

## Usage
One notable feature of the program is the use of dynamic memory allocation (malloc) to convert numbers to strings in different bases. The convert_to function takes a number and a base as input and returns a dynamically allocated string representing the number in the specified base. The program also includes error handling for some cases, such as when a null string is passed as an argument to the my_printf function.


### The Core Team


<span><i>Made at <a href='https://qwasar.io'>Qwasar SV -- Software Engineering School</a></i></span>
<span><img alt='Qwasar SV -- Software Engineering School's Logo' src='https://storage.googleapis.com/qwasar-public/qwasar-logo_50x50.png' width='20px'></span>
