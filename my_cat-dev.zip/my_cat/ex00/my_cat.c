#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    if (argc < 2) {
        printf("my_cat: missing file operand\n");
        return 1;
    }
    for (int i = 1; i < argc; i++) {
        FILE *file = fopen(argv[i], "r");
        if (file == NULL) {
            printf("my_cat: %s: No such file or directory\n", argv[i]);
            continue;
        }
        int c;
        while ((c = getc(file)) != EOF) {
            putchar(c);
        }
        fclose(file);
    }
    return 0;
}