const express = require('express');
const app = express();
const port = 8080;
const basicAuth = require('express-basic-auth');


app.get('/', (req, res) => {
    const song_list = ["All I Need is the Girl","All My Tomorrows","All or Nothing at All","Almost Like Being in Love","Around the World","Autumn Leaves","Ave Maria","April in Paris","Anytime", "Anywhere","All I Do Is Dream of You","All By Myself"]
    const randSong = Math.floor(Math.random()*song_list.length);
    res.send(song_list[randSong]);
});

app.get('/birth_date', (req,res) => {
    res.send('December 12, 1915')
});

app.get('/birth_city', (req, res) => {
    res.send('Hoboken, New Jersey')
});

app.get('/wives',(req, res) => {
    const wives = ["Nancy Barbato", "Ava Gardner" , "Mia Farrow", "Barbara Marx"];
    res.send(wives.join(', '))
});

app.get('/picture', (req, res) => {
    res.send(`<img scr="https://upload.wikimedia.org/wikipedia/commons/a/af/Frank_Sinatra_%2757.jpg">`);
});

app.get ('/public', (req,res)=> {
  res.send ("Everybody can see this page")
});
app.use(basicAuth({
    users: {
        'admin': 'admin'
    },
    unauthorizedResponse: (req) =>{
        return '401 Not authorized\n';
    }
}));

app.get('/protected',(req,res) =>{
    res.send('Welcome, authenticated client\n');
});
app.listen(port,() =>{
    console.log('Example app listening at http://web-i700d25be-59f7.docode.fi.qwasar.io/%27');
});