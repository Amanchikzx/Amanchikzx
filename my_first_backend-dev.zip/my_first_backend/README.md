# Welcome to My First Backend
***

## Task
Task requested to use framework express. It will have a route GET on /. This action will give randomly (in a pool of at least 20) a name of a song from Frank Sinatra. Created file in directory app.js. 
## Description
We have called express framework through const, used port 8080 and authentication function as well. We requested song, birthday, city, wives, picture and public.

## Installation
Need to install framework express, we used special command npm install express --save. | const express = require('express'); |const app = express();

## Usage
The main idea of this task is to get/request information. For instance, through special command we can get information, we get randomly one song of Frank Sinatra. authentication function was installed, need to obtain access to get info (login admin and password admin) as it it protected. 
./my_project argument1 argument2
```

### The Core Team


<span><i>Made at <a href='https://qwasar.io'>Qwasar SV -- Software Engineering School by Gadylbek Mendygaliyev and Amanzhol Rakhymov</a></i></span>
<span><img alt='Qwasar SV -- Software Engineering School's Logo' src='https://storage.googleapis.com/qwasar-public/qwasar-logo_50x50.png' width='20px'></span>
